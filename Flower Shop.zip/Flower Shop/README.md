# Flower-shop
online shopping tool for flowers and gifts
Flower shop is an online responsive shopping website with beautiful menu options and pictures.The shopping cart code is not included here.I made this using HTML5,CSS3
and Bootstrap.It has google fonts also.Feel free to use any of its features.

click on the URL below for a lookup

https://happypetals.000webhostapp.com/
